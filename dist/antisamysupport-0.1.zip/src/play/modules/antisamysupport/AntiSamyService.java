package play.modules.antisamysupport;

public interface AntiSamyService {
  public String filter(String input);
}
