
AntiSamy plugin for Play framework
==================================


# Usage

*    name your policy file to antisamy.xml and put it under conf/ of your application directory
*    invoke AntiSamyPlugin.filter() to filter dirty string input, you'll get a clean string output (the degree of cleanliness depends on your policy file)
    String clean = AntiSamyPlugin.filter(dirty);


# Reference

##AntiSamy project
https://www.owasp.org/index.php/Category:OWASP_AntiSamy_Project

##AntiSamy Google code
http://code.google.com/p/owaspantisamy/



